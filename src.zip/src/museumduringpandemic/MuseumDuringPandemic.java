package museumduringpandemic;

import simulator.Simulator;

import java.text.ParseException;

public class MuseumDuringPandemic {

    public static void main(String[] args) throws ParseException {
        Simulator sim = new Simulator();
        sim.startSimulate();
    }

}
